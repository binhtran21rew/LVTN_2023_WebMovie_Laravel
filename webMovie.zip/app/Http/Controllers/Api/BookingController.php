<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Exception;
class BookingController extends Controller
{
    private $booking;
    private $ticket;

    public function __construct(Booking $booking, Ticket $ticket){
        $this->booking = $booking;
        $this->ticket = $ticket;
    }


    public function bookingTicket(Request $request){

        
        if(!auth('sanctum')->check()){
            return response()->json([
                'status' => 401,
                'message' => 'You must be logged in to book this ticket',
            ]);
        }

        try{
            DB::beginTransaction();
            $dataBooking = [
                'user_id' => auth('sanctum')->user()->id,
                'count' => $request->count,
                'date' => $request->date,
                'total_price' => $request->total_price,
                'status' => ''
            ];
            $loadBooking = $this->booking->create($dataBooking);
    
            $dataTicket = [
                'booking_id' => $loadBooking->id,
                'status' => 1
            ];
            $checkTicket = $this->ticket->whereIn('id',  $request->ticket)->update($dataTicket);
            
            // $checkTicket->update($dataTicket);
            DB::commit();
            return response()->json([
                'status' => 200,
                'message' => 'Booking successfully',
            ]);
        }catch(Exception $e){
            DB::rollBack();
            return $e;
        }
       

    }
}
