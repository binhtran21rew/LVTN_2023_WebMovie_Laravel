<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\MovieRequest;
use App\Http\Resources\MovieDetailResource;
use App\Http\Resources\MovieResource;
use App\Models\Cast;
use App\Models\Genre;
use App\Models\Movie;
use App\Models\Movie_cast;
use App\Models\Movie_detail;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Traits\StoreImg;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;
use Ramsey\Uuid\Type\Integer;

class MovieController extends Controller
{
    use StoreImg;
    private $movie;
    private $cast;
    private $movie_detail;
    private $genre;
    public function __construct(Movie $movie, Cast $cast, Movie_detail $movie_detail, Genre $genre){
        $this->movie = $movie;
        $this->cast = $cast;
        $this->movie_detail = $movie_detail;
        $this->genre = $genre;
    }
    public function createMovie(MovieRequest $request){
        try{
            DB::beginTransaction();
            $minutes = $request->time;
            $formatted_time = floor($minutes / 60) . ':'. ($minutes -   floor($minutes / 60) * 60).':00';

            $uploadPoster = $this->imgUpload($request, 'post_path', 'movie');
            $uploadBackdrop = $this->imgUpload($request, 'backdrop_path', 'movie');
            $movie = $this->movie->create([
                'title' => $request->title,
                'post_path' => $uploadPoster,
                'backdrop_path' => $uploadBackdrop,
                'release' => $request->release,
                'time' => $formatted_time,
            ]);
            $movieDetail = $this->movie_detail->create([
                'movie_id' => $movie['id'],
                'title' => $movie['title'],
                'overview' =>  $request->overview ?? '',
                'vote_count' => 0,
                'vote_average' => 0,
                'status'  => $request->status
            ]);
            if($request->casts){
                foreach($request->casts as $value){
                    $cast = $this->cast->find($value);
                    $castID[] = $cast->id;
                }
                $movie->movie_cast()->attach($castID);
            }
            if($request->genres){
                foreach( $request->genres as $value){
                    $genre = $this->genre->find($value);
                    $genreID[] = $genre->id;
                }
                $movieDetail->movie_genre()->attach($genreID);
            }
            DB::commit();
            return response()->json([
                'status' => 200,
                'message' => 'Created successfully',
            ]);
        }catch(Exception $e){
            DB::rollBack();
            return $e->getMessage();
        }
    }


    public function getMovieId($id){
        $cache = Cache::get('movie_'.$id);
        if(isset($cache)){
            return $cache;
        }
        $movie = $this->movie->find($id);

        if($movie){
            Cache::remember('movie_'.$id, 60*60*24,function() use($movie){
                return  $movie;
            });
            return $cache;
        }
        return  response()->json([
            'status' => 404,
            'message' => 'Not found movie'
        ]);
    }
    public function movieDetail($id){
        $cache = Cache::get('movie_detail_'.$id);
        if(isset($cache)){
            return $cache;
        }
        $detail = $this->movie_detail->load(['movie', 'movie_genre'])->where('id', $id)->first();
        if($detail){
            Cache::remember('movie_detail_'.$id, 60*60*24, function() use ($detail){
                return new MovieDetailResource($detail);
            });
            return $cache;
        }
        return  response()->json([
            'status' => 404,
            'message' => 'Not found movie'
        ]);
    }
    public function getAdminMovie(){

        $cache = Cache::get('allMovieAdmin');
        if(isset($cache)){
            return $cache;
        }
        
        Cache::remember('allMovieAdmin', 60*60*24, function(){
            return $this->movie_detail->load(['movie.movie_cast', 'movie_genre'])->get()->map(function($d){
                return new MovieDetailResource($d);
            });
        });

        // Cache::delete('allMovieAdmin');
        return $cache;
    }
    public function getAll(){
        $cache = Cache::get('allMovieShow');

        if(isset($cache)){
            return $cache;
        }
        Cache::remember('allMovieShow', 60*60*24, function(){
            return $this->movie->withWhereHas('movie_detail', fn($query) => 
                $query->where('status', 1)
            )->get()->map(function($movie){
                return new MovieResource($movie);
            });
        });
        return $cache;


    }
    public function getPage($page){
        $limitPerPage = 6;
        $newPage = (($page - 1) * $limitPerPage);

        $movies = $this->movie->offset($newPage)->limit($limitPerPage)->get();
        foreach($movies as $movie){
            $data[] = new MovieResource($movie);
        }

        return $data;
    }



    public function getMovieContent($type){
        $cache = Cache::get('movie_content_'.$type);

        if(isset($cache)){
            return $cache;
        }

        Cache::remember('movie_content_'.$type, 60*60*24, function() use ($type){
            return $this->movie->withWhereHas('movie_detail', fn($query) =>
                $query->where('status', $type)
            )->limit(8)->get()->map(function($movie){
                return new MovieResource($movie);
            });
        });
        return $cache;

    }


    public function updateMovie(Request $request){
        try{
            DB::beginTransaction();
            $minutes = $request->time;
            $formatted_time = floor($minutes / 60) . ':'. ($minutes -   floor($minutes / 60) * 60).':00';

            $checkMovie = $this->movie->find($request->movie_id);
            if($checkMovie){
                $checkDetail = $this->movie_detail->where('movie_id', $request->movie_id)->first();
                $uploadPoster = $this->imgUpload($request, 'post_path', 'movie');
                $uploadBackdrop = $this->imgUpload($request, 'backdrop_path', 'movie');

                $dataMovie = [
                    'title' => $request->title,
                    'release' => $request->release,
                    'time' => $formatted_time,
                ];
                $dataDetail = [
                    'title' => $request->title,
                    'overview' => $request->overview,
                    'status' => $request->status,
                ];
                if(!empty($uploadPoster)){
                    File::delete(public_path($checkMovie->post_path));
                    $dataMovie['post_path'] = $uploadPoster;
                }
                if(!empty($uploadBackdrop)){
                    File::delete(public_path($checkMovie->backdrop_path));
                    $dataMovie['backdrop_path'] = $uploadBackdrop;
                }
                if($request->casts){
                    foreach($request->casts as $value){
                        $cast = $this->cast->find($value);
                        $castID[] = $cast->id;
                    }
                    $checkMovie->movie_cast()->sync($castID);
                }
                if($request->genres){
                    foreach( $request->genres as $value){
                        $genre = $this->genre->find($value);
                        $genreID[] = $genre->id;
                    }
                    $checkDetail->movie_genre()->sync($genreID);
                }
                $checkMovie->update($dataMovie);
                $checkDetail->update($dataDetail);
                DB::commit();
                return  response()->json([
                    'status' => 200,
                    'message' => 'Update successfully'
                ]);
            }
        }catch(Exception $e){
            DB::rollBack();
        }
    }

}
